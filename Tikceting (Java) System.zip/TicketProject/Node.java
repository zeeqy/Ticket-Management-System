public class Node {
	Object element;
	Node next;
		
	public Node(Object element) {
		this.element = element;
	}

}
